"use client";

import React, { useEffect, useMemo, useState } from "react";
import { Icon } from "@iconify/react";
import { motion } from "framer-motion";

const LINKS = [
  { href: "#hero", label: "Home" },
  { href: "#services", label: "Services" },
  { href: "#portfolio", label: "Portfolio" },
  { href: "#about", label: "About" },
  { href: "#team", label: "Team" },
  { href: "#reviews", label: "Reviews" },
  { href: "#contact", label: "Contact" },
];

export default function Navbar() {
  const [active, setActive] = useState<string>("#hero");
  const [open, setOpen] = useState<boolean>(false);
  const sections = useMemo(() => [
    "hero",
    "services",
    "portfolio",
    "about",
    "team",
    "reviews",
    "contact",
  ], []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(`#${entry.target.id}`);
          }
        });
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: [0.2, 0.4, 0.6] }
    );

    sections.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [sections]);

  useEffect(() => {
    const onHashChange = () => setOpen(false);
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  const onNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const id = href.replace("#", "");
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
      setActive(href);
    }
    setOpen(false);
  };

  return (
    <div className="sticky top-0 z-50 w-full">
      <div className="mx-auto max-w-7xl px-4">
        <div className="mt-3 flex items-center justify-between rounded-full border border-white/10 bg-white/60 px-4 py-2 backdrop-blur-md shadow-sm">
          <a href="#hero" onClick={(e) => onNavClick(e, "#hero")} className="flex items-center gap-2">
            <Icon icon="material-symbols:rocket-rounded" className="text-indigo-600" width={22} height={22} />
            <span className="text-sm font-medium tracking-tight">Marketing Missile</span>
          </a>
          <nav className="hidden md:flex items-center gap-1">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => onNavClick(e, link.href)}
                className={`px-3 py-2 text-sm rounded-full transition-colors ${
                  active === link.href ? "bg-indigo-600 text-white" : "text-slate-700 hover:bg-black/5"
                }`}
              >
                {link.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <a
              href="/chat"
              className="hidden md:inline-flex items-center gap-1 rounded-full bg-white/70 px-3 py-2 text-xs text-slate-700 hover:bg-white"
            >
              <Icon icon="material-symbols:chat" width={16} height={16} />
              Chat
            </a>
            <a
              href="#contact"
              onClick={(e) => onNavClick(e, "#contact")}
              className="hidden md:inline-flex items-center gap-1 rounded-full bg-indigo-600 px-3 py-2 text-xs text-white"
            >
              <Icon icon="mdi:bullhorn" width={16} height={16} />
              Get proposal
            </a>
            <button
              aria-label="Open menu"
              className="md:hidden rounded-full p-2 hover:bg-black/5"
              onClick={() => setOpen((v) => !v)}
            >
              <Icon icon={open ? "material-symbols:close" : "material-symbols:menu"} width={22} height={22} />
            </button>
          </div>
        </div>
      </div>
      {/* Mobile sheet */}
      {open && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="mx-4 mt-2 rounded-2xl border border-white/10 bg-white/70 p-3 backdrop-blur-md shadow-sm md:hidden"
        >
          <div className="flex flex-col">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => onNavClick(e, link.href)}
                className={`px-3 py-2 text-sm rounded-lg ${
                  active === link.href ? "bg-indigo-600 text-white" : "text-slate-700 hover:bg-black/5"
                }`}
              >
                {link.label}
              </a>
            ))}
            <a href="/chat" className="mt-1 px-3 py-2 text-sm rounded-lg text-slate-700 hover:bg-black/5 inline-flex items-center gap-2">
              <Icon icon="material-symbols:chat" width={18} height={18} />
              Chat
            </a>
          </div>
        </motion.div>
      )}
    </div>
  );
}