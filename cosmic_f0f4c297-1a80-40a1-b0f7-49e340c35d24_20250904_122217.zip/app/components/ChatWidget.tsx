"use client";

import React from "react";
import { Icon } from "@iconify/react";
import { motion, AnimatePresence } from "framer-motion";
import ChatBot from "@/app/components/ChatBot";

export default function ChatWidget() {
  const [open, setOpen] = React.useState<boolean>(false);

  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-50">
      <div className="pointer-events-auto flex flex-col items-end gap-3">
        <AnimatePresence>
          {open && (
            <motion.div
              key="panel"
              initial={{ opacity: 0, y: 12, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 12, scale: 0.98 }}
              transition={{ duration: 0.18 }}
              className="w-[92vw] max-w-[360px] overflow-hidden rounded-2xl shadow-2xl"
            >
              <ChatBot />
            </motion.div>
          )}
        </AnimatePresence>

        <button
          aria-label={open ? "Close chat" : "Open chat"}
          onClick={() => setOpen((v) => !v)}
          className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-indigo-600 text-white shadow-lg hover:bg-indigo-500"
        >
          <Icon icon={open ? "material-symbols:close" : "material-symbols:chat"} width={24} height={24} />
        </button>
      </div>
    </div>
  );
}
