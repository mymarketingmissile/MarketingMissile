"use client";

import React from "react";
import { Icon } from "@iconify/react";
import { motion, AnimatePresence } from "framer-motion";
import {
  services,
  projects,
  team as teamMembers,
  aboutBullets,
  testimonials,
  contactEmail,
} from "@/app/content";

type ChatKind =
  | "text"
  | "services"
  | "projects"
  | "team"
  | "about"
  | "reviews"
  | "contact";

type ChatMessage = {
  role: "user" | "bot";
  kind: ChatKind;
  text?: string;
};

const suggestions = [
  { label: "Show services", kind: "services" as ChatKind },
  { label: "Show projects", kind: "projects" as ChatKind },
  { label: "About you", kind: "about" as ChatKind },
  { label: "Team", kind: "team" as ChatKind },
  { label: "Client reviews", kind: "reviews" as ChatKind },
  { label: "Contact info", kind: "contact" as ChatKind },
];

function renderBotContent(msg: ChatMessage) {
  switch (msg.kind) {
    case "services":
      return (
        <div className="space-y-2">
          <p className="text-xs text-slate-600">Here are our core services:</p>
          <ul className="list-disc pl-4 space-y-1">
            {services.map((s) => (
              <li key={s.title} className="text-xs text-slate-800">
                <span className="font-medium text-slate-900">{s.title}:</span> {s.desc}
              </li>
            ))}
          </ul>
          <a href="#services" className="mt-2 inline-flex text-[11px] text-indigo-600 hover:underline">Go to Services</a>
        </div>
      );
    case "projects":
      return (
        <div className="space-y-2">
          <p className="text-xs text-slate-600">A snapshot of recent work:</p>
          <ul className="list-disc pl-4 space-y-1">
            {projects.map((p) => (
              <li key={p.title} className="text-xs text-slate-800">
                <span className="font-medium text-slate-900">{p.title}</span> — {p.tag}
              </li>
            ))}
          </ul>
          <a href="#portfolio" className="mt-2 inline-flex text-[11px] text-indigo-600 hover:underline">See Portfolio</a>
        </div>
      );
    case "team":
      return (
        <div className="space-y-2">
          <p className="text-xs text-slate-600">Meet the team:</p>
          <ul className="list-disc pl-4 space-y-1">
            {teamMembers.map((m) => (
              <li key={m.name} className="text-xs text-slate-800">
                <span className="font-medium text-slate-900">{m.name}</span> — {m.role}
              </li>
            ))}
          </ul>
          <a href="#team" className="mt-2 inline-flex text-[11px] text-indigo-600 hover:underline">See Team</a>
        </div>
      );
    case "about":
      return (
        <div className="space-y-2">
          <p className="text-xs text-slate-600">About Marketing Missile:</p>
          <ul className="list-disc pl-4 space-y-1">
            {aboutBullets.map((b) => (
              <li key={b} className="text-xs text-slate-800">{b}</li>
            ))}
          </ul>
          <a href="#about" className="mt-2 inline-flex text-[11px] text-indigo-600 hover:underline">Learn more</a>
        </div>
      );
    case "reviews":
      return (
        <div className="space-y-2">
          <p className="text-xs text-slate-600">What clients say:</p>
          <ul className="list-disc pl-4 space-y-1">
            {testimonials.map((t) => (
              <li key={t.name} className="text-xs text-slate-800">
                “{t.quote}” — <span className="font-medium text-slate-900">{t.name}</span>, {t.designation}
              </li>
            ))}
          </ul>
          <a href="#reviews" className="mt-2 inline-flex text-[11px] text-indigo-600 hover:underline">Read reviews</a>
        </div>
      );
    case "contact":
      return (
        <div className="space-y-2">
          <p className="text-xs text-slate-600">You can reach us at:</p>
          <p className="text-xs"><span className="font-medium text-slate-900">Email:</span> {contactEmail}</p>
          <a href="#contact" className="mt-2 inline-flex text-[11px] text-indigo-600 hover:underline">Go to Contact form</a>
        </div>
      );
    default:
      return <p className="text-xs text-slate-800">{msg.text}</p>;
  }
}

function classify(text: string): ChatKind {
  const q = text.toLowerCase();
  if (/service|offer|pricing|capabilit/.test(q)) return "services";
  if (/project|portfolio|work|case/.test(q)) return "projects";
  if (/team|people|member/.test(q)) return "team";
  if (/about|company|who|what/.test(q)) return "about";
  if (/review|testimonial|client/.test(q)) return "reviews";
  if (/contact|email|reach|proposal|talk/.test(q)) return "contact";
  return "text";
}

export default function ChatBot({ autoFocus = false }: { autoFocus?: boolean }) {
  const [messages, setMessages] = React.useState<ChatMessage[]>([
    {
      role: "bot",
      kind: "text",
      text: "Hi! I can show you our services, projects, team, reviews, or contact info. What would you like to see?",
    },
  ]);
  const [input, setInput] = React.useState<string>("");
  const listRef = React.useRef<HTMLDivElement | null>(null);

  React.useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages.length]);

  function addUser(text: string) {
    setMessages((m) => [...m, { role: "user", kind: "text", text }]);
  }

  function addBot(kind: ChatKind, text?: string) {
    setMessages((m) => [...m, { role: "bot", kind, text }]);
  }

  function handleSend(text: string) {
    const trimmed = text.trim();
    if (!trimmed) return;
    addUser(trimmed);
    const k = classify(trimmed);
    if (k === "text") {
      // fallback
      addBot(
        "text",
        "Got it. I can show services, projects, team, reviews, or contact info. Try one of the quick options below."
      );
    } else {
      addBot(k);
    }
    setInput("");
  }

  return (
    <div className="flex h-full w-full flex-col overflow-hidden rounded-2xl border border-black/10 bg-white/80 shadow-lg backdrop-blur-md">
      <div className="relative flex items-center justify-between border-b border-black/5 px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="h-6 w-6 rounded-full bg-indigo-600/90" />
          <div>
            <div className="text-sm font-medium text-slate-900">Marketing Missile Chat</div>
            <div className="text-[11px] text-slate-500">Ask about services, projects and more</div>
          </div>
        </div>
        <a href="/chat" className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-slate-700">
          <Icon icon="material-symbols:chat-outline" width={16} height={16} />
          Open full chat
        </a>
      </div>

      <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
        <AnimatePresence>
          {messages.map((m, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
              className={`max-w-[85%] rounded-xl px-3 py-2 text-xs ${
                m.role === "user"
                  ? "ml-auto bg-indigo-600 text-white"
                  : "bg-white border border-black/10 text-slate-800"
              }`}
            >
              {m.role === "user" ? <span>{m.text}</span> : renderBotContent(m)}
            </motion.div>
          ))}
        </AnimatePresence>

        <div className="mt-1 flex flex-wrap gap-2">
          {suggestions.map((s) => (
            <button
              key={s.label}
              type="button"
              onClick={() => {
                addUser(s.label);
                addBot(s.kind);
              }}
              className="rounded-full border border-black/10 bg-white/70 px-3 py-1 text-[11px] text-slate-700 hover:bg-white"
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      <form
        className="flex items-center gap-2 border-t border-black/5 p-3"
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(input);
        }}
      >
        <input
          className="flex-1 rounded-full border border-black/10 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder="Type your question..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          autoFocus={autoFocus}
        />
        <button
          type="submit"
          className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-indigo-600 text-white disabled:opacity-50"
          disabled={!input.trim()}
        >
          <Icon icon="material-symbols:send-rounded" width={18} height={18} />
        </button>
      </form>
    </div>
  );
}
