"use client";

import React from "react";
import { Icon } from "@iconify/react";

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-black/5 bg-white/70 backdrop-blur-sm">
      <div className="mx-auto max-w-7xl px-4 py-10">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
          <div>
            <div className="flex items-center gap-2">
              <Icon icon="material-symbols:rocket-rounded" className="text-indigo-600" width={20} height={20} />
              <span className="text-sm font-medium">Marketing Missile</span>
            </div>
            <p className="mt-3 text-sm text-slate-600">We help brands launch, grow, and win.</p>
          </div>
          <div>
            <h4 className="text-sm font-medium text-slate-800">Company</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              <li><a href="#about" className="hover:text-indigo-600">About</a></li>
              <li><a href="#portfolio" className="hover:text-indigo-600">Work</a></li>
              <li><a href="#team" className="hover:text-indigo-600">Team</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-medium text-slate-800">Get in touch</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              <li className="flex items-center gap-2"><Icon icon="ic:baseline-email" width={16} height={16} /> hello@marketingmissile.co</li>
              <li><a href="#contact" className="inline-flex items-center gap-1 hover:text-indigo-600"><Icon icon="mdi:target" width={16} height={16} /> Start a project</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 flex items-center justify-between text-xs text-slate-500">
          <p>&copy; {new Date().getFullYear()} Marketing Missile. All rights reserved.</p>
          <div className="flex items-center gap-3">
            <a aria-label="Twitter" href="#" className="hover:text-indigo-600"><Icon icon="mdi:twitter" width={16} height={16} /></a>
            <a aria-label="LinkedIn" href="#" className="hover:text-indigo-600"><Icon icon="mdi:linkedin" width={16} height={16} /></a>
            <a aria-label="GitHub" href="#" className="hover:text-indigo-600"><Icon icon="mdi:github" width={16} height={16} /></a>
          </div>
        </div>
      </div>
    </footer>
  );
}