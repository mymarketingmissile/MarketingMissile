export type Service = { title: string; desc: string; icon: string };
export type Project = { title: string; tag: string };
export type Person = { name: string; role: string; u: string };
export type Testimonial = { quote: string; name: string; designation: string; src: string };

export const services: Service[] = [
  {
    title: 'Growth Strategy',
    desc: 'Go-to-market, positioning, and funnels built to scale.',
    icon: 'mdi:target',
  },
  {
    title: 'Performance Marketing',
    desc: 'Paid search, social, and CRO that drives measurable ROI.',
    icon: 'material-symbols:analytics-rounded',
  },
  {
    title: 'Brand & Creative',
    desc: 'Messaging, identity, and content that people remember.',
    icon: 'mdi:bullhorn',
  },
  {
    title: 'Web & Experience',
    desc: 'High-converting websites and landing pages.',
    icon: 'material-symbols:shield-rounded',
  },
];

export const projects: Project[] = [
  { title: 'Fintech Ads Engine', tag: 'Paid Social / CRO' },
  { title: 'SaaS Website Overhaul', tag: 'Web / UX' },
  { title: 'DTC Brand Launch', tag: 'Brand / GTM' },
  { title: 'Analytics Revamp', tag: 'Data / Reporting' },
  { title: 'SEO Content System', tag: 'SEO / Content' },
  { title: 'B2B ABM Program', tag: 'Demand Gen' },
];

export const aboutBullets: string[] = [
  'Senior team with startup + enterprise experience',
  'Performance-first creative powered by insight',
  'Transparent reporting and clear next steps',
];

export const team: Person[] = [
  { name: 'Ava Patel', role: 'Head of Growth', u: 'team1' },
  { name: 'Lucas Kim', role: 'Creative Director', u: 'team2' },
  { name: 'Maya Singh', role: 'Performance Lead', u: 'team3' },
  { name: 'Ethan Ross', role: 'Strategy Partner', u: 'team4' },
];

export const testimonials: Testimonial[] = [
  {
    quote:
      'They unlocked a new growth engine for us in 60 days. The reporting and communication were top-tier.',
    name: 'Sarah Chen',
    designation: 'VP Marketing, TechFlow',
    src: 'https://i.pravatar.cc/400?u=review1',
  },
  {
    quote:
      'Creative that actually converts. We saw a 38% lift in paid CAC within the first quarter.',
    name: 'Michael Rodriguez',
    designation: 'CMO, InnovateSphere',
    src: 'https://i.pravatar.cc/400?u=review2',
  },
  {
    quote:
      'Senior team, zero fluff. Strategy was sharp and execution was fast.',
    name: 'Emily Watson',
    designation: 'COO, CloudScale',
    src: 'https://i.pravatar.cc/400?u=review3',
  },
];

export const contactEmail = 'hello@marketingmissile.com';
