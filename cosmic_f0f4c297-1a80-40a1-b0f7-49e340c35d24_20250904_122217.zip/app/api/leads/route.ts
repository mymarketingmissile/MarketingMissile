import { NextResponse } from "next/server";
import { db } from "cosmic-database";

export async function POST(request: Request) {
  try {
    const data = (await request.json()) as {
      name?: string;
      email?: string;
      company?: string;
      message?: string;
    };

    if (!data?.email || !data?.name) {
      return NextResponse.json({ error: "Name and email are required" }, { status: 400 });
    }

    const doc = await db.collection("leads").add({
      name: data.name,
      email: data.email,
      company: data.company ?? "",
      message: data.message ?? "",
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp(),
      source: "marketing-missile-site",
    });

    return NextResponse.json({ success: true, id: doc.id });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (id) {
      const snap = await db.collection("leads").doc(id).get();
      if (!snap.exists) return NextResponse.json({ error: "Not found" }, { status: 404 });
      return NextResponse.json({ id: snap.id, ...snap.data() });
    }

    const snapshot = await db.collection("leads").limit(25).get();
    const leads = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
    return NextResponse.json({ leads });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
