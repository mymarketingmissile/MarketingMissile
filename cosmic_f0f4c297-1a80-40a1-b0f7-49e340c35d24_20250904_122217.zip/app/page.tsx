'use client';

import React, { useState } from 'react';
import { Icon } from '@iconify/react';
import { motion } from 'framer-motion';
import AnimatedTestimonials from '@/app/components/AnimatedTestimonials';
import { services as servicesData, projects as projectsData, aboutBullets, team as teamMembers, testimonials as testimonialsData, contactEmail } from '@/app/content';

export default function Home() {
  return (
    <div className="flex flex-col">
      <Hero />
      <Services />
      <Portfolio />
      <About />
      <Team />
      <Reviews />
      <Contact />
    </div>
  );
}

function SectionWrapper({ id, children, className }: { id: string; children: React.ReactNode; className?: string }) {
  return (
    <section id={id} className={`mx-auto w-full max-w-7xl px-4 py-16 sm:py-24 ${className ?? ''}`}>
      {children}
    </section>
  );
}

function Hero() {
  return (
    <section
      id="hero"
      className="relative flex min-h-[92vh] items-center justify-center overflow-hidden"
      style={{
        backgroundImage:
          'linear-gradient(111.4deg, rgba(7,7,9,1) 6.5%, rgba(27,24,113,1) 93.2%)',
      }}
    >
      <div className="absolute inset-0 opacity-30" aria-hidden>
        <div className="absolute -top-20 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-indigo-500 blur-3xl" />
        <div className="absolute bottom-0 right-10 h-60 w-60 rounded-full bg-blue-400 blur-3xl" />
      </div>
      <div className="relative mx-auto flex w-full max-w-7xl flex-col items-center px-4 text-center text-white">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-[clamp(28px,6vw,52px)] font-medium leading-tight tracking-tight"
        >
          Marketing Missile
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mt-4 max-w-2xl text-sm text-white/80"
        >
          We ignite growth for ambitious brands with strategy, creative, and performance marketing that actually converts.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-8 flex flex-col items-center gap-3 sm:flex-row"
        >
          <a href="#contact" className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm text-slate-900">
            <Icon icon="mdi:bullhorn" width={18} height={18} /> Get a proposal
          </a>
          <a href="#portfolio" className="inline-flex items-center gap-2 rounded-full bg-white/10 px-5 py-3 text-sm text-white backdrop-blur-sm">
            <Icon icon="material-symbols:analytics-rounded" width={18} height={18} /> See our work
          </a>
        </motion.div>
      </div>
    </section>
  );
}

function Services() {
  return (
    <SectionWrapper id="services">
      <motion.h2
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center text-2xl font-medium text-slate-900"
      >
        Services
      </motion.h2>
      <p className="mx-auto mt-2 max-w-2xl text-center text-sm text-slate-600">
        Full-funnel strategy, creative, and media under one roof.
      </p>
      <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {servicesData.map((s) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4 }}
            className="rounded-2xl border border-black/5 bg-white/70 p-5 backdrop-blur-sm"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600/10 text-indigo-700">
              <Icon icon={s.icon} width={18} height={18} />
            </div>
            <h3 className="mt-4 text-base font-medium text-slate-900">{s.title}</h3>
            <p className="mt-1 text-sm text-slate-600">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </SectionWrapper>
  );
}

function Portfolio() {
  return (
    <SectionWrapper id="portfolio">
      <motion.h2
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center text-2xl font-medium text-slate-900"
      >
        Portfolio
      </motion.h2>
      <p className="mx-auto mt-2 max-w-2xl text-center text-sm text-slate-600">
        A sampling of recent wins. Visuals available on request.
      </p>
      <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {projectsData.map((p, i) => (
          <motion.div
            key={p.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.05 }}
            className="group relative overflow-hidden rounded-2xl border border-black/5 bg-gradient-to-br from-slate-50 to-indigo-50 p-5"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-indigo-700">
                <Icon icon="material-symbols:rocket-rounded" width={18} height={18} />
                <span className="text-xs">{p.tag}</span>
              </div>
              <Icon icon="material-symbols:chevron-right-rounded" width={18} height={18} className="text-slate-500" />
            </div>
            <h3 className="mt-4 text-base font-medium text-slate-900">{p.title}</h3>
            <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-indigo-500/20 blur-2xl transition-opacity group-hover:opacity-70" />
          </motion.div>
        ))}
      </div>
    </SectionWrapper>
  );
}

function About() {
  return (
    <SectionWrapper id="about">
      <div className="grid grid-cols-1 items-center gap-8 md:grid-cols-2">
        <div>
          <motion.h2
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-2xl font-medium text-slate-900"
          >
            About us
          </motion.h2>
          <p className="mt-2 text-sm text-slate-600">
            We combine strategy, creative, and media to deliver compounding growth. No fluff, just outcomes.
          </p>
          <ul className="mt-4 space-y-2 text-sm text-slate-700">
            {aboutBullets.map((b) => (
              <li key={b} className="flex items-start gap-2">
                <Icon icon="mdi:check-circle" className="text-green-600" width={16} height={16} />
                <span>{b}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="relative">
          <div className="h-56 w-full rounded-2xl border border-black/5 bg-white/70 backdrop-blur-sm" />
          <div className="pointer-events-none absolute -left-6 -top-6 h-24 w-24 rounded-full bg-indigo-400/30 blur-2xl" />
          <div className="pointer-events-none absolute -right-6 -bottom-6 h-24 w-24 rounded-full bg-blue-400/30 blur-2xl" />
        </div>
      </div>
    </SectionWrapper>
  );
}

function Team() {
  return (
    <SectionWrapper id="team">
      <motion.h2
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center text-2xl font-medium text-slate-900"
      >
        Team
      </motion.h2>
      <p className="mx-auto mt-2 max-w-2xl text-center text-sm text-slate-600">
        Small, senior, and hands-on.
      </p>
      <div className="mt-10 grid grid-cols-2 gap-6 sm:grid-cols-4">
        {teamMembers.map((p) => (
          <div key={p.name} className="text-center">
            <img
              src={`https://i.pravatar.cc/400?u=${encodeURIComponent(p.u)}`}
              alt={p.name}
              className="mx-auto h-24 w-24 rounded-full object-cover shadow-sm"
            />
            <div className="mt-3 text-sm font-medium text-slate-900">{p.name}</div>
            <div className="text-xs text-slate-600">{p.role}</div>
          </div>
        ))}
      </div>
    </SectionWrapper>
  );
}

function Reviews() {
  return (
    <SectionWrapper id="reviews" className="py-10">
      <motion.h2
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center text-2xl font-medium text-slate-900"
      >
        Client Reviews
      </motion.h2>
      <p className="mx-auto mt-2 max-w-2xl text-center text-sm text-slate-600">
        A few words from teams we partner with.
      </p>
      <AnimatedTestimonials testimonials={testimonialsData} autoplay />
    </SectionWrapper>
  );
}

function Contact() {
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setDone(null);
    const form = e.currentTarget;
    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());

    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: (payload.name as string) ?? "",
          email: (payload.email as string) ?? "",
          company: (payload.company as string) ?? "",
          message: (payload.message as string) ?? "",
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Something went wrong");
      setDone('Thanks! We&apos;ll be in touch within 1 business day.');
      form.reset();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <SectionWrapper id="contact">
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        <div>
          <motion.h2
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-2xl font-medium text-slate-900"
          >
            Contact
          </motion.h2>
          <p className="mt-2 text-sm text-slate-600">
            Tell us a bit about your goals and we&apos;ll send a tailored proposal.
          </p>
          <ul className="mt-4 space-y-2 text-sm text-slate-700">
            <li className="flex items-center gap-2"><Icon icon="ic:baseline-email" width={16} height={16} /> {contactEmail}</li>
          </ul>
        </div>
        <div>
          <form onSubmit={onSubmit} className="rounded-2xl border border-black/5 bg-white/70 p-6 backdrop-blur-sm">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="sm:col-span-1">
                <label htmlFor="name" className="text-xs text-slate-700">Name</label>
                <input id="name" name="name" required className="mt-1 w-full rounded-md border border-black/10 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="sm:col-span-1">
                <label htmlFor="email" className="text-xs text-slate-700">Email</label>
                <input id="email" name="email" type="email" required className="mt-1 w-full rounded-md border border-black/10 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="company" className="text-xs text-slate-700">Company</label>
                <input id="company" name="company" className="mt-1 w-full rounded-md border border-black/10 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="message" className="text-xs text-slate-700">Message</label>
                <textarea id="message" name="message" rows={4} className="mt-1 w-full rounded-md border border-black/10 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="mt-4 inline-flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2 text-sm text-white disabled:opacity-60"
            >
              <Icon icon="material-symbols:send-rounded" width={18} height={18} />
              {loading ? 'Sending...' : 'Send'}
            </button>
            {done && <p className="mt-3 text-xs text-green-700">{done}</p>}
            {error && <p className="mt-3 text-xs text-red-600">{error}</p>}
          </form>
        </div>
      </div>
    </SectionWrapper>
  );
}