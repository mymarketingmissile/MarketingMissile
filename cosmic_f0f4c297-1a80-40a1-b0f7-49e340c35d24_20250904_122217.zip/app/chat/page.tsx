'use client';

import React from 'react';
import { motion } from 'framer-motion';
import ChatBot from '@/app/components/ChatBot';

export default function ChatPage() {
  return (
    <section className="min-h-[80vh] w-full bg-[linear-gradient(180deg,#fafafa,rgba(99,102,241,0.06))]">
      <div className="mx-auto w-full max-w-5xl px-4 py-16 sm:py-24">
        <motion.h1
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="mb-6 text-center text-[clamp(22px,4.5vw,36px)] font-medium text-slate-900"
        >
          Chat with Marketing Missile
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.05 }}
          className="mx-auto mb-8 max-w-2xl text-center text-sm text-slate-600"
        >
          Ask about our services, projects, team, reviews, or how to get in touch.
        </motion.p>
        <div className="mx-auto max-w-3xl">
          <ChatBot autoFocus />
        </div>
      </div>
    </section>
  );
}
