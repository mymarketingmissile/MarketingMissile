import type { Metadata } from "next";
import { Geist } from "next/font/google";
import "./globals.css";
import { CosmicAnalyticsProvider } from "cosmic-analytics";

import Navbar from "@/app/components/Navbar";
import Footer from "@/app/components/Footer";
import ChatWidget from "@/app/components/ChatWidget";

const primaryFont = Geist({
  weight: ["400", "600", "700"],
  subsets: ["latin"],
});

// Change the title and description to your own.
export const metadata: Metadata = {
  title: "Marketing Missile — Growth that ignites",
  description: "A sleek, animated single-page marketing site with services, work, team, reviews, and contact.",
};

export default function RootLayout({
  children,
  
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={primaryFont.className}>
      <body className="antialiased min-h-screen flex flex-col">
          <CosmicAnalyticsProvider>
            <Navbar />
            <main className="flex-1">{children}</main>
            <ChatWidget />
            <Footer />
          </CosmicAnalyticsProvider>
      </body>
    </html>
  );
}